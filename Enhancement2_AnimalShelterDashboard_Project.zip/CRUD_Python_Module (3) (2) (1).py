"""
CRUD_Python_Module.py

This module defines the AnimalShelter class, which provides
Create, Read, Update, and Delete (CRUD) operations for the
Grazioso Salvare MongoDB database.
"""

from typing import Optional, Dict, Any, List
from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """
    AnimalShelter provides CRUD operations for the 'animals'
    collection in the 'aac' MongoDB database.
    """

    def __init__(
        self,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 27017,
        db_name: str = "aac",
        collection_name: str = "animals",
    ):
        """
        Initialize the connection to MongoDB using the provided credentials.
        The user authenticates against the 'admin' database and then accesses 'aac'.
        """
        uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin"
        self.client = MongoClient(uri)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    def _is_valid_dict(self, value: Any) -> bool:
        """Return True if the given value is a dictionary."""
        return isinstance(value, dict)

    # -------------------- CREATE -------------------- #
    def create(self, data: Dict[str, Any]) -> bool:
        """Insert a single document into the collection."""
        if not self._is_valid_dict(data) or not data:
            print("Create error: data must be a non-empty dictionary.")
            return False

        try:
            result = self.collection.insert_one(data)
            return result.inserted_id is not None
        except PyMongoError as error:
            print(f"An error occurred in create(): {error}")
            return False

    # -------------------- READ -------------------- #
    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, Any]] = None,
        sort: Optional[List[tuple]] = None,
        limit: int = 0
    ) -> List[Dict[str, Any]]:
        """
        Query for document(s) in the collection.

        :param query: Dictionary representing filter criteria. If None/empty, returns all docs.
        :param projection: Optional projection dictionary, e.g. {"_id": 0}
        :param sort: Optional list of tuples for sorting, e.g. [("age_upon_outcome_in_weeks", 1)]
        :param limit: Optional max number of documents to return. 0 means no limit.
        :return: List of matching documents (empty list on error).
        """
        try:
            q = {} if query is None else query

            if not self._is_valid_dict(q):
                print("Read error: query must be a dictionary.")
                return []

            if projection is not None and not self._is_valid_dict(projection):
                print("Read error: projection must be a dictionary.")
                return []

            if sort is not None and not isinstance(sort, list):
                print("Read error: sort must be a list of tuples.")
                return []

            if not isinstance(limit, int) or limit < 0:
                print("Read error: limit must be a non-negative integer.")
                return []

            cursor = self.collection.find(q, projection)

            if sort:
                cursor = cursor.sort(sort)

            if limit > 0:
                cursor = cursor.limit(limit)

            return list(cursor)

        except PyMongoError as error:
            print(f"An error occurred in read(): {error}")
            return []

    # -------------------- UPDATE -------------------- #
    def update(self, query: Dict[str, Any], new_values: Dict[str, Any], multiple: bool = False) -> int:
        """Update document(s) that match the query."""
        if not self._is_valid_dict(query) or not self._is_valid_dict(new_values):
            print("Update error: query and new_values must be dictionaries.")
            return 0

        if not new_values:
            print("Update error: new_values must not be empty.")
            return 0

        try:
            update_doc = {"$set": new_values}
            result = (
                self.collection.update_many(query, update_doc)
                if multiple
                else self.collection.update_one(query, update_doc)
            )
            return result.modified_count

        except PyMongoError as error:
            print(f"An error occurred in update(): {error}")
            return 0

    # -------------------- DELETE -------------------- #
    def delete(self, query: Dict[str, Any], multiple: bool = False) -> int:
        """Delete document(s) that match the query."""
        if not self._is_valid_dict(query):
            print("Delete error: query must be a dictionary.")
            return 0

        try:
            result = (
                self.collection.delete_many(query)
                if multiple
                else self.collection.delete_one(query)
            )
            return result.deleted_count

        except PyMongoError as error:
            print(f"An error occurred in delete(): {error}")
            return 0

    def close(self) -> None:
        """Close the MongoDB client connection."""
        self.client.close()